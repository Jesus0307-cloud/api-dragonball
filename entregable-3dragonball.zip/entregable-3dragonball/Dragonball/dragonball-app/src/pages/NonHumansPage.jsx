import React, { useEffect, useState } from 'react';
import { getCharacters } from '../api';
import CharacterCard from '../components/CharacterCard';

function NonHumansPage() {
  const [characters, setCharacters] = useState([]);

  useEffect(() => {
    const fetchCharacters = async () => {
      const data = await getCharacters();
      const nonHumanCharacters = data.filter(character => character.race !== "Human");
      setCharacters(nonHumanCharacters);
    };
    fetchCharacters();
  }, []);

  return (
    <div className="nonhuman-page"> {}
      <h1>Non-Human Characters</h1> {}
      <div className="character-grid"> {}
        {characters.map(character => (
          <CharacterCard key={character.id} character={character} />
        ))}
      </div>
    </div>
  );
}

export default NonHumansPage;
