import React from 'react';

function AboutPage() {
  return (
    <div>
      <h1>Acerca de dragon ball</h1>
      <h1>pajina de jesus david moreno hoyos</h1>
      <h1>je.moreno@udla.edu.co</h1>
    </div>
  );
}

export default AboutPage;