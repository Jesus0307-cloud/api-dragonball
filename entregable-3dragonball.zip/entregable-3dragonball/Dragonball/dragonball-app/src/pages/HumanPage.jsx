import React, { useEffect, useState } from 'react';
import { getCharacters } from '../api';
import CharacterCard from '../components/CharacterCard';

function HumansPage() {
  const [characters, setCharacters] = useState([]);

  useEffect(() => {
    const fetchCharacters = async () => {
      const data = await getCharacters();
      const humanCharacters = data.filter(character => character.race === "Human");
      setCharacters(humanCharacters);
    };
    fetchCharacters();
  }, []);

  return (
    <div className="human-page"> {}
      <h1>Personajes Humanos</h1> {}
      <div className="character-grid"> {}
        {characters.map(character => (
          <CharacterCard key={character.id} character={character} />
        ))}
      </div>
    </div>
  );
}

export default HumansPage;
