import React from 'react';
import { Card, CardContent, CardMedia, Typography, Button } from '@mui/material';
import { Link } from 'react-router-dom';

function CharacterCard({ character }) {
  return (
    <Card>
      <CardMedia
        component="img"
        image={character.image}
        alt={character.name}
        style={{ 
          objectFit: 'contain', 
          height: '250px', 
          width: '100%', 
          borderRadius: '10px 10px 0 0' 
        }} 
      />
      <CardContent>
        <Typography gutterBottom variant="h5" component="div">
          {character.name}
        </Typography>
        <Button component={Link} to={`/character/${character.id}`}>
          Ver Detalles
        </Button>
      </CardContent>
    </Card>
  );
}

export default CharacterCard;
